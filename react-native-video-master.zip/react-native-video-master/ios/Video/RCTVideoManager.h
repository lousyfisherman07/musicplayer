#import <React/RCTViewManager.h>
#import <React/RCTBridgeModule.h>

@interface RCTVideoManager : RCTViewManager <RCTBridgeModule>

@end
