export default {
  SRT: 'application/x-subrip',
  TTML: 'application/ttml+xml',
  VTT: 'text/vtt',
};
