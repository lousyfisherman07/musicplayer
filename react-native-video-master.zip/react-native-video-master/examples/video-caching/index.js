import { AppRegistry, Platform } from "react-native";
import App from "./App";

AppRegistry.registerComponent("VideoCaching", () => App);
