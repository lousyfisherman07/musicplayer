### Current behavior
Describe what happens when you encounter this issue.

### Reproduction steps
A 1, 2, 3, etc. list of what's needed to see the issue happen.

### Expected behavior
Describe what you wanted to happen

### Platform
Which player are you experiencing the problem on:
* iOS
* Android ExoPlayer
* Android MediaPlayer
* Windows UWP
* Windows WPF

### Video sample
If possible, include a link to the video that has the problem that can be streamed or downloaded from.
