// @flow

export default {
  ScaleNone: 0,
  ScaleToFill: 1,
  ScaleAspectFit: 2,
  ScaleAspectFill: 3,
};
