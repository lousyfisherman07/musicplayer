// @flow

module.exports = require("./RCTVideoManager");
